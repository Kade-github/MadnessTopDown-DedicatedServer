namespace DedicatedServer.Madness.Packets;

public class CPacketHeartbeat : Packet
{
    protected CPacketHeartbeat() : base(PacketType.CPacketHeartBeat)
    {
    }
}