namespace DedicatedServer.Madness.Server;

public class ConnectionHandle
{
    
}